# 各个文件的作用

| 名字           | 作用                     |
| -------------- | ------------------------ |
| data/Data1.txt | 题目一输入数据，一共20个 |
|data/Data2.txt| 题目二输入数据，一共20个|
|AutoTest_1.do|题目一的仿真脚本，使用在modelsim命令行下使用``do AutoTest_1.do``运行|
|AutoTest_2.do|题目二的仿真脚本，用法同上|
|NumberOfOne.v|题目一的设计文件，需要自行实现|
|NumberOfPrfixZero.v|题目二的设计文件，需要自行实现|
|reslut1.txt|题目一的仿真结果保存文件，每行分别是输入数据，仿真输出数据，每运行一次.do文件都会更新.txt|
|reslut2.txt|题目二的仿真结果保存文件，同上|
|testbench_1.v|题目一仿真文件，不要修改|
|testbench_2.v|题目一仿真文件，不要修改|