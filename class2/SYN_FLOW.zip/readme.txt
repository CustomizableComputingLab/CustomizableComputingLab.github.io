1:复制rtl代码文件夹到rtl_code文件夹下
2:修改setup中各个初始化文件的设置
3:在SYN_FLOW文件夹下，打开linux系统的terminal命令行，输入source run.sh "X"
(X为希望指定的DC_log的名字)