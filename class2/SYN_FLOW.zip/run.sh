# 获取第一个命令行参数作为X的值，如果未提供参数则使用默认值
X=${1:-default_value}

# 获取当前日期和时间，格式为 YYYYMMDD_HHMM
DATE=$(date "+%Y%m%d_%H%M")

tclsh ./common/top.tcl
cd work
dc_shell -64bit -f ./script.tcl |tee ${X}_${DATE}.log